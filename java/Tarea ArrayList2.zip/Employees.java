package com.digitech.employees;

import java.util.ArrayList;
import java.util.Scanner;

public class Employees {

    public static void main(String[] args) {
        
        ArrayList<String> listaNombres = new ArrayList<>();   
        Scanner Scanner =new Scanner(System.in);
        
        String nombres;
        int opc_menu=0;
        
    //3. Realizar un programa para gestionar la lista de Empleados, en que tendremos el siguiente menú: 
    //1. Agregar Nombres. 
    //2. Modificar nombre 
    //3. Borrar Nombres. 
    //4. Visualizar un Nombre 
    //5. Visualizar todos Nombres. 
    //6. Salir.  
          
        while (true) {
            System.out.println("1. Agregar Nombres");
            System.out.println("2. Modificar Nombre");
            System.out.println("3. Borrar Nombres");
            System.out.println("4. Visualizar un Nombre");
            System.out.println("5. Visualizar todos los Nombres");
            System.out.println("6. Salir");
            opc_menu = Scanner.nextInt();
            Scanner.nextLine(); // Limpiar el buffer

            switch (opc_menu) {
                case 1:
                    System.out.println("¿Cuántos nombres queremos introducir en el ArrayList?");
                    int cantidad = Scanner.nextInt();
                    Scanner.nextLine(); // Limpiar el buffer
                    
                    for (int i = 0; i < cantidad; i++) {
                        System.out.print("Ingrese el nombre del empleado: ");
                        String names = Scanner.nextLine();
                        listaNombres.add(names);
                    }
                        break;
    //Se ha agregado un caso en el switch para modificar un nombre. 
    //Solicita al usuario que ingrese el nombre que desea cambiar. 
    //Si el nombre es válido, se solicita el nuevo nombre y se actualiza en la lista.
                    
                case 2:
                    
                    System.out.println("Ingrese la posición del nombre que desea modificar (0 a " + (listaNombres.size() - 1) + "):");
                    int nombreModificar = Scanner.nextInt();
                    Scanner.nextLine(); // Limpiar el buffer

                    if (nombreModificar >= 0 && nombreModificar < listaNombres.size()) {
                    System.out.print("Ingrese el nuevo nombre: ");
                    String nuevoNombre = Scanner.nextLine();
                    listaNombres.set(nombreModificar, nuevoNombre);
                    System.out.println("Nombre modificado con éxito.");
                    } else {
                    System.out.println("Índice inválido.");
                    
                    }
                    break;
                    
    //La opción 3, nos dirá como queremos borrar, nos tiene que dar opción a borrar por posición o por nombre:    
                    
                case 3:
                    
                    System.out.println("Ingrese el posición del nombre que desea borrar (0 a " + (listaNombres.size() - 1) + "):");
                    int posicionBorrar = Scanner.nextInt();
                    Scanner.nextLine(); // Limpiar el buffer

                    if (posicionBorrar >= 0 && posicionBorrar < listaNombres.size()) {
                    listaNombres.remove(posicionBorrar);
                    System.out.println("Nombre borrado con éxito.");
                    } else {
                        System.out.println("Índice inválido.");
                        
                    }
                    break;
                    
    //La opción 4 muestra un nombre, según la posición que queremos, hay que comprobar que la posición es correcta.      
                    
                case 4:
                    
                    System.out.println("Ingrese el índice del nombre que desea visualizar (0 a " + (listaNombres.size() - 1) + "):");
                    int posicionVisualizar = Scanner.nextInt();
                    Scanner.nextLine(); // Limpiar el buffer

                    if (posicionVisualizar >= 0 && posicionVisualizar < listaNombres.size()) {
                        System.out.println("Nombre en índice " + posicionVisualizar + ": " + listaNombres.get(posicionVisualizar));
                    } else {
                        System.out.println("Índice inválido.");
                    
                    }
                    break;
                    
    //La opción 5 muestra por pantalla un listado de todos los empleados.
                    
                case 5:
                    System.out.println("Lista de todos los nombres:");
                    for (int i = 0; i < listaNombres.size(); i++) {
                        System.out.println(i + ": " + listaNombres.get(i));
                    
                    }
                    break;

    //Tras procesar cada opción, se debe mostrar de nuevo el menú inicial, hasta que se seleccione la opción 6, que terminará el programa.
                
                case 6:
                    
                    System.out.println("Saliendo del programa.");
                    Scanner.close();
                    System.exit(0);
                    
                    break;

                default:
                    
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }
}
                    
                
    
        
        
    

