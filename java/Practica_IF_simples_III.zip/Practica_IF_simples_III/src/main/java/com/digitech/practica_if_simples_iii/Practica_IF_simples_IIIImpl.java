/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.digitech.practica_if_simples_iii;


public class Practica_IF_simples_IIIImpl extends Practica_IF_simples_III {
    
}
