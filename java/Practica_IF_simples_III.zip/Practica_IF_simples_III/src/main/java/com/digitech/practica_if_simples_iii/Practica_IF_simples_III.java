package com.digitech.practica_if_simples_iii;

import java.util.Scanner;

public class Practica_IF_simples_III {

public static void main(String[]args){	
    
    Scanner datos=new Scanner(System.in);
    int numero1;
    int numero2;
    System.out.println("Ingrese el primer numero : ");
    numero1=datos.nextInt();
    System.out.println("ingrese el segundo numero : ");
    numero2=datos.nextInt();
    if(numero1>numero2)
      System.out.println("el numero mayor es : " + numero1);
    else
      System.out.println("el numero mayor es : " + numero2);
    }
   }


