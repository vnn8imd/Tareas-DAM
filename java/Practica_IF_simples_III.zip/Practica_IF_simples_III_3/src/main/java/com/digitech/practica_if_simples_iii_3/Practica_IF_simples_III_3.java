package com.digitech.practica_if_simples_iii_3;

import java.util.Scanner;

    public class Practica_IF_simples_III_3 {

    public static void main(String[] args) {
    Scanner datos=new Scanner(System.in);
    
    int num1;
    int num2;
    int num3;
    
    System.out.println("Ingrese el primer numero : ");
    num1=datos.nextInt();
    System.out.println("ingrese el segundo numero : ");
    num2=datos.nextInt();
    System.out.println("ingrese el segundo numero : ");
    num3=datos.nextInt();  
    
    if (num1 < num2) {
            if (num1 < num3) {
                System.out.println("El menor es: " + num1);                                             
            }
            
            else {
                System.out.println("el menor es: " + num3);     
            }
        }
            else if (num2 < num3) {
            System.out.println("el menor es: " + num2);
            
        } else {
            System.out.println("el menor es: " + num3);
        }
   }
}

