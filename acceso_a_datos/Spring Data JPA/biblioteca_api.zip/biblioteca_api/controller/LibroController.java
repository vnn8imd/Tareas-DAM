package com.dam.ad.biblioteca_api.controller;
import com.dam.ad.biblioteca_api.exception.NotFoundException;
import com.dam.ad.biblioteca_api.model.Libro;
import com.dam.ad.biblioteca_api.repository.LibroRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/libros")
public class LibroController {
    private final LibroRepository repo;
    public LibroController(LibroRepository repo) {
        this.repo = repo;
    }
    @GetMapping
    public List<Libro> findAll() {
        return repo.findAll();
    }
    @GetMapping("/{id}")
    public Libro findById(@PathVariable Integer id) {
        return repo.findById(id)
                .orElseThrow(() -> new NotFoundException("No existe libro id=" + id));
    }
    @GetMapping("/disponibles")
    public List<Libro> findDisponibles() {
        return repo.findByDisponibleTrue();
    }
    @GetMapping("/buscar")
    public List<Libro> buscarPorTitulo(@RequestParam String texto) {
        return repo.findByTituloContainingIgnoreCase(texto);
    }
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping
    public Libro create(@Valid @RequestBody Libro libro) {
        if (libro.getId() != null) {
            throw new IllegalArgumentException("No mandes id en el POST");
        }
        if (repo.existsByIsbn(libro.getIsbn())) {
            throw new IllegalArgumentException("Ya existe un libro con ese ISBN");
        }
        return repo.save(libro);
    }
    @PutMapping("/{id}")
    public Libro update(@PathVariable Integer id, @Valid @RequestBody Libro cambios) {
        Libro actual = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("No existe libro id=" + id));
        actual.setTitulo(cambios.getTitulo());
        actual.setIsbn(cambios.getIsbn());
        actual.setAnio(cambios.getAnio());
        actual.setDisponible(cambios.isDisponible());
        return repo.save(actual);
    }
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        if (!repo.existsById(id)) {
            throw new NotFoundException("No existe libro id=" + id);
        }
        repo.deleteById(id);
    }
}