package com.dam.ad.biblioteca_api.controller;

import com.dam.ad.biblioteca_api.exception.NotFoundException;
import com.dam.ad.biblioteca_api.model.Usuario;
import com.dam.ad.biblioteca_api.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioRepository repo;
    public UsuarioController(UsuarioRepository repo) {
        this.repo = repo;
    }
    @GetMapping
    public List<Usuario> findAll() {
        return repo.findAll();
    }
    @GetMapping("/{id}")
    public Usuario findById(@PathVariable Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));
    }
    @PostMapping
    public ResponseEntity<Usuario> create(@Valid @RequestBody Usuario usuario) {
        if (repo.existsByEmail(usuario.getEmail())) {
            throw new IllegalArgumentException("Ya existe un usuario con ese email");
        }
        Usuario saved = repo.save(usuario);
        return ResponseEntity.created(URI.create("/api/usuarios/" + saved.getId())).body(saved);
    }

}
