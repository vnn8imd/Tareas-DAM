package com.dam.ad.biblioteca_api.controller;

import com.dam.ad.biblioteca_api.dto.PrestamoResponse;
import com.dam.ad.biblioteca_api.dto.PrestarRequest;
import com.dam.ad.biblioteca_api.service.PrestamoService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
@RestController
@RequestMapping("/api/prestamos")
public class PrestamoController {

    private final PrestamoService service;

    public PrestamoController(PrestamoService service) {
        this.service = service;
    }
    @PostMapping
    public ResponseEntity<PrestamoResponse> prestar(@Valid @RequestBody PrestarRequest req) {
        PrestamoResponse res = service.prestarLibro(req);
        return ResponseEntity.created(URI.create("/api/prestamos/" + res.id)).body(res);
    }
    @PostMapping("/{id}/devolucion")
    public PrestamoResponse devolver(@PathVariable Long id) {
        return service.devolverLibro(id);
    }
    @GetMapping("/usuarios/{usuarioId}/activos")
    public List<PrestamoResponse> activosPorUsuario(@PathVariable Long usuarioId) {
        return service.buscarActivosPorUsuario(usuarioId);
    }
}
