package com.dam.ad.biblioteca_api.dto;

import jakarta.validation.constraints.NotNull;

public class PrestarRequest {

    @NotNull
    public Long usuarioId;
    @NotNull
    public Integer libroId;
}

