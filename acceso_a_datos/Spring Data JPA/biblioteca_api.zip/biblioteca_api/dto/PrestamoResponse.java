package com.dam.ad.biblioteca_api.dto;

import java.time.LocalDateTime;

public class PrestamoResponse {
    public Long id;
    public Long usuarioId;
    public Integer libroId;
    public LocalDateTime fechaPrestamo;
    public LocalDateTime fechaDevolucion;
    public boolean devuelto;
}