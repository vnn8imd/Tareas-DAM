package com.dam.ad.biblioteca_api.repository;

import com.dam.ad.biblioteca_api.model.Prestamo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PrestamoRepository extends JpaRepository<Prestamo, Long> {
    List<Prestamo> findByUsuarioIdAndDevueltoFalse(Long usuarioId);
}
