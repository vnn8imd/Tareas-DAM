package com.dam.ad.biblioteca_api.repository;

import com.dam.ad.biblioteca_api.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    boolean existsByEmail(String email);
}

