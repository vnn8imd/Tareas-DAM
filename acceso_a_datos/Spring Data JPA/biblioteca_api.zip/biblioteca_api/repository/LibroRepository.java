package com.dam.ad.biblioteca_api.repository;
import com.dam.ad.biblioteca_api.model.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LibroRepository extends JpaRepository<Libro, Integer> {

    /**
     * Comprueba si existe un libro por su ISBN
     */
    boolean existsByIsbn(String isbn);

    /**
     * Busca todos los libros que tengan el atributo disponible en true
     */
    List<Libro> findByDisponibleTrue();

    /**
     * Busca libros cuyo título contenga una cadena de texto, ignorando mayúsculas/minúsculas
     */
    List<Libro> findByTituloContainingIgnoreCase(String titulo);

}