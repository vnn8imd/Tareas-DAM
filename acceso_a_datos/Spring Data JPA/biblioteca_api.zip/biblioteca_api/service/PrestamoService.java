package com.dam.ad.biblioteca_api.service;

import com.dam.ad.biblioteca_api.dto.PrestamoResponse;
import com.dam.ad.biblioteca_api.dto.PrestarRequest;
import com.dam.ad.biblioteca_api.exception.NotFoundException;
import com.dam.ad.biblioteca_api.model.Libro;
import com.dam.ad.biblioteca_api.model.Prestamo;
import com.dam.ad.biblioteca_api.model.Usuario;
import com.dam.ad.biblioteca_api.repository.LibroRepository;
import com.dam.ad.biblioteca_api.repository.PrestamoRepository;
import com.dam.ad.biblioteca_api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
@Service

public class PrestamoService {

    private final UsuarioRepository usuarioRepo;
    private final LibroRepository libroRepo;
    private final PrestamoRepository prestamoRepo;
    public PrestamoService(UsuarioRepository usuarioRepo,
                           LibroRepository libroRepo,
                           PrestamoRepository prestamoRepo) {
        this.usuarioRepo = usuarioRepo;
        this.libroRepo = libroRepo;
        this.prestamoRepo = prestamoRepo;
    }

    @Transactional
    public PrestamoResponse prestarLibro(PrestarRequest req) {
        Usuario usuario = usuarioRepo.findById(req.usuarioId)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));
        Libro libro = libroRepo.findById(req.libroId)
                .orElseThrow(() -> new NotFoundException("Libro no encontrado"));
        if (!libro.isDisponible()) {
            throw new IllegalArgumentException("El libro no está disponible");
        }
        Prestamo prestamo = new Prestamo();
        prestamo.setUsuario(usuario);
        prestamo.setLibro(libro);
        prestamo.setFechaPrestamo(LocalDateTime.now());
        prestamo.setDevuelto(false);
        prestamoRepo.save(prestamo);
        libro.setDisponible(false);
        libroRepo.save(libro);
        return toResponse(prestamo);
    }

    @Transactional
    public PrestamoResponse devolverLibro(Long prestamoId) {
        Prestamo prestamo = prestamoRepo.findById(prestamoId)
                .orElseThrow(() -> new NotFoundException("Préstamo no encontrado"));
        if (prestamo.isDevuelto()) {
            throw new IllegalArgumentException("El préstamo ya estaba devuelto");
        }
        prestamo.setDevuelto(true);
        prestamo.setFechaDevolucion(LocalDateTime.now());
        Libro libro = prestamo.getLibro();
        libro.setDisponible(true);
        libroRepo.save(libro);
        prestamoRepo.save(prestamo);
        return toResponse(prestamo);
    }

    @Transactional(readOnly = true)
    public List<PrestamoResponse> buscarActivosPorUsuario(Long usuarioId) {
        return prestamoRepo.findByUsuarioIdAndDevueltoFalse(usuarioId)
                .stream()
                .map(this::toResponse)
                .toList();
    }
    private PrestamoResponse toResponse(Prestamo p) {
        PrestamoResponse res = new PrestamoResponse();
        res.id = p.getId();
        res.usuarioId = p.getUsuario().getId();
        res.libroId = p.getLibro().getId();
        res.fechaPrestamo = p.getFechaPrestamo();
        res.fechaDevolucion = p.getFechaDevolucion();
        res.devuelto = p.isDevuelto();
        return res;
    }
}
