package com.dam.ad.biblioteca_api.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
@Entity
@Table(name = "libro")
public class Libro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @NotBlank
    @Column(nullable = false, length = 150)
    private String titulo;
    @NotBlank
    @Column(nullable = false, unique = true, length = 40)
    private String isbn;
    @NotNull
    @Column(name = "anio", nullable = false)
    private Integer anio;
    @Column(nullable = false)
    private boolean disponible = true;
    public Libro() {
    }
    public Integer getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getIsbn() { return isbn; }
    public Integer getAnio() { return anio; }
    public boolean isDisponible() { return disponible; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public void setAnio(Integer anio) { this.anio = anio; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
}