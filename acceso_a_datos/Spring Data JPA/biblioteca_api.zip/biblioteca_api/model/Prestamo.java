package com.dam.ad.biblioteca_api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
@Table(name = "prestamo")
public class Prestamo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "libro_id", nullable = false)
    private Libro libro;
    @Column(name = "fecha_prestamo", nullable = false)
    private LocalDateTime fechaPrestamo;
    @Column(name = "fecha_devolucion")
    private LocalDateTime fechaDevolucion;
    @Column(nullable = false)
    private boolean devuelto = false;
    public Prestamo() {
    }
    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public Libro getLibro() { return libro; }
    public LocalDateTime getFechaPrestamo() { return fechaPrestamo; }
    public LocalDateTime getFechaDevolucion() { return fechaDevolucion; }
    public boolean isDevuelto() { return devuelto; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public void setLibro(Libro libro) { this.libro = libro; }
    public void setFechaPrestamo(LocalDateTime fechaPrestamo) { this.fechaPrestamo = fechaPrestamo; }
    public void setFechaDevolucion(LocalDateTime fechaDevolucion) { this.fechaDevolucion =
            fechaDevolucion; }
    public void setDevuelto(boolean devuelto) { this.devuelto = devuelto; }
}
