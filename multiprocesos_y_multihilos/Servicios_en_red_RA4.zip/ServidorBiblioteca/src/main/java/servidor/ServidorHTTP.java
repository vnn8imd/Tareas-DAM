package servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorHTTP {
    
  public static void main(String[] args) {
        int puerto = 8080; // Puerto requerido por la tarea
        
        try (ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("Servidor iniciado en http://localhost:" + puerto);

            while (true) {
                // El servidor se queda esperando a que alguien entre
                Socket cliente = servidor.accept(); 
                System.out.println("¡Alguien se ha conectado!");

                // Creamos un hilo para atender a este cliente y seguir escuchando otros
                Thread hilo = new Thread(new ManejadorPeticion(cliente));
                hilo.start();
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
}
