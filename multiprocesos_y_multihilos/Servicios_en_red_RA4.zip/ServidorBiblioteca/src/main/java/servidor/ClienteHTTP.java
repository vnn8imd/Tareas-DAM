package servidor;

import java.io.*;
import java.net.*;

public class ClienteHTTP {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 8080;

        // Intentamos conectarnos al servidor que ya tienes corriendo
        try (Socket socket = new Socket(host, puerto);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            // Enviamos la petición GET para la contraseña
            out.println("GET /password HTTP/1.1");
            out.println("Host: " + host);
            out.println(); // Línea en blanco para finalizar la petición
            out.flush(); //asegura que se envía ya

            // Leemos la respuesta del servidor
            String linea;
            System.out.println("--- Respuesta del Servidor ---");
            while ((linea = in.readLine()) != null) {
                System.out.println(linea);
            }

        } catch (IOException e) {
            System.err.println("Error al conectar con el servidor: " + e.getMessage());
        }
    }
}