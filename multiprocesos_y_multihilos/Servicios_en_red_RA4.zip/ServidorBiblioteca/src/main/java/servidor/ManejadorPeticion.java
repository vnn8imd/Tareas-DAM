package servidor;

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;


public class ManejadorPeticion implements Runnable {
    private Socket socket;

    public ManejadorPeticion(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedOutputStream dataOut = new BufferedOutputStream(socket.getOutputStream())) {

            // 1. Leemos la petición del cliente[cite: 1]
            String linea = in.readLine();
            if (linea == null) return;

            // 2. Extraemos la ruta (ej: "/" o "/password")[cite: 1]
            StringTokenizer st = new StringTokenizer(linea);
            st.nextToken(); // Salta el "GET"
            String ruta = st.nextToken(); // Aquí tenemos la ruta[cite: 1]

            // 3. Lógica de rutas de la tarea[cite: 1]
            if (ruta.equals("/")) {
                enviarArchivo(out, dataOut, "index.html", "text/html");
            } else if (ruta.equals("/password")) {
                enviarTexto(out, dataOut, "PSP_DAM", "text/plain");
            } else {
                // Si la ruta no es correcta, enviamos 404[cite: 1]
                out.println("HTTP/1.1 404 Not Found");
                out.println();
                out.flush();
            }

        } catch (IOException e) {
            System.err.println("Error con el cliente: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException e) {}
        }
    }

    private void enviarTexto(PrintWriter out, BufferedOutputStream dataOut, String texto, String tipo) throws IOException {
        out.println("HTTP/1.1 200 OK");
        out.println("Content-Type: " + tipo);
        out.println("Content-Length: " + texto.length());
        out.println(); // Línea en blanco obligatoria[cite: 1]
        out.flush();
        dataOut.write(texto.getBytes());
        dataOut.flush();
    }

    private void enviarArchivo(PrintWriter out, BufferedOutputStream dataOut, String nombreArchivo, String tipo) throws IOException {
        File f = new File(nombreArchivo);
        if (f.exists()) {
            int longitud = (int) f.length();
            byte[] datos = new byte[longitud];
            try (FileInputStream fis = new FileInputStream(f)) {
                fis.read(datos);
            }
            out.println("HTTP/1.1 200 OK");
            out.println("Content-Type: " + tipo);
            out.println("Content-Length: " + longitud);
            out.println(); // Línea en blanco obligatoria[cite: 1]
            out.flush();
            dataOut.write(datos);
            dataOut.flush();
        }
    }
}